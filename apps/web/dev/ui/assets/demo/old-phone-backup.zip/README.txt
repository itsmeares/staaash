Backup of Jesse's old phone, made before the trade-in.
