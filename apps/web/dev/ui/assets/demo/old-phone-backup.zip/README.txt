Backup of Sam's old phone, made before the trade-in.
